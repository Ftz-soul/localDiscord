#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/select.h>
#include <sys/wait.h>

#define MAX_USERS 20        //limitazione: massimo numero di user nel server è statico 
#define MAX_NAME 32         //massima lunghezza nome utente,canale
#define MAX_TEXT 256        //massima lunghezza messaggio 

typedef enum {
    MSG_PUBLIC = 0,
    MSG_PRIVATE,    //1
    MSG_CHANGECH, //2
    MSG_DISCONNECT, //3
    MSG_CONNECT, //4
    MSG_SHUTDOWN, //5
    MSG_ERROR, //6
    MSG_JOIN,//7
    MSG_LEAVE //8
} MsgType;

typedef struct {
    MsgType type; //tipo messaggio 
    char sender[MAX_NAME]; //mittente 
    char recipient[MAX_NAME];  //destinatario
    char channel[MAX_NAME]; //canale 
    char text[MAX_TEXT];  //testo
} Message;

typedef struct {
    int active; //stato utente 0 inattivo ,1 attivo
    char name[MAX_NAME]; //nome utente
    char channel[MAX_NAME]; //nome canale 
    char fifo[MAX_NAME + 8]; //nome fifo privata
} User;

//array di utenti
static User users[MAX_USERS];

//funzione che restituisce l'indice dell'utente attivo con quel nome 
static int find_user_index(const char *name) {
    for (int i = 0; i < MAX_USERS; i++)
        if (users[i].active && strcmp(users[i].name, name) == 0)
            return i;
    return -1;
}
//manda il messaggio a tutti quelli attivi del canale tranne al mittente
static void broadcast(Message *msg, const char *channel, const char *except) {
    //per ogni utente 
    for (int i = 0; i < MAX_USERS; i++) {
        //controllo quali sono attivi, appartengono allo stesso canale e non siano il mittente
        if (users[i].active && strcmp(users[i].channel, channel) == 0 && strcmp(users[i].name, except) != 0)
        {
            //apri la fifo privata degli utenti in sola scrittura e non block 
            int fd = open(users[i].fifo, O_WRONLY | O_NONBLOCK);
            if (fd != -1) {
                //scrive il messaggio 
                write(fd, msg, sizeof(*msg));
                //chiudo il descrittore di file
                close(fd);
            }
        }
    }
}

//gestisce connessione utente
static void handle_connect(Message *msg) {
    //controllo se l'utente ha lo stesso nome di uno già commesso
    if (find_user_index(msg->sender) != -1) {
        Message err = {MSG_ERROR, "server", "", "", ""};
        strcpy(err.recipient, msg->sender);
        snprintf(err.text, sizeof(err.text),"User '%s' is already connected.", msg->sender);
        char fq[MAX_NAME+8];
        snprintf(fq, sizeof(fq), "%s_fifo", msg->sender);
        int fd = open(fq, O_WRONLY | O_NONBLOCK);
        if (fd != -1) {
            write(fd, &err, sizeof(err));
            close(fd);
        }
        return;
    }
    //inizializza l'utente
    for (int i = 0; i < MAX_USERS; i++) {
        if (!users[i].active) {
            users[i].active = 1;
            strcpy(users[i].name, msg->sender);
            strcpy(users[i].channel, msg->channel);
            snprintf(users[i].fifo, sizeof(users[i].fifo),"%s_fifo", msg->sender);
            // notifica CONNECT
            int fd = open(users[i].fifo, O_WRONLY);
            if (fd != -1) {
                msg->type = MSG_CONNECT;
                //mando il connect avvenuto allo user che lo ha mandato
                write(fd, msg, sizeof(*msg));
                close(fd);
            }
            // broadcast JOIN a tutti quelli del canale per mostrare chi si è unito
            Message jm = {MSG_JOIN, "", "", "", "joined the channel."};
            strcpy(jm.sender, msg->sender);
            broadcast(&jm, msg->channel, msg->sender);
            break;
        }
    }
}

//gestisce disconnessione utente
static void handle_disconnect(Message *msg) {
    int idx = find_user_index(msg->sender);
    if (idx >= 0) {
        // broadcast LEAVE agli altri del canale
        Message lm = {MSG_LEAVE, "", "", "", "left the channel."};
        strcpy(lm.sender, msg->sender);
        broadcast(&lm, users[idx].channel, msg->sender);
        // invia DISCONNECT al mittente
        Message dc = {MSG_DISCONNECT, "server", "", "", "You have been disconnected."};
        char fq[MAX_NAME+8];
        snprintf(fq, sizeof(fq), "%s_fifo", msg->sender);
        int fd = open(fq, O_WRONLY | O_NONBLOCK);
        if (fd != -1) {
            //mando la disconnessione
            write(fd, &dc, sizeof(dc));
            close(fd); 
            
        }
        users[idx].active = 0;
    }
}

//gestisce cambio canale
static void handle_change_channel(Message *msg) {
    int idx = find_user_index(msg->sender);
    if (idx >= 0) {
        //manda l'abbandono dell'utente dal canale ai membri del canale vecchio
        Message lm = {MSG_LEAVE, "", "", "", "left the channel."};
        strcpy(lm.sender, msg->sender);
        broadcast(&lm, users[idx].channel, msg->sender);
        strcpy(users[idx].channel, msg->channel);
        //manda l'entrata dell'utente nel canale nuovo ai membri di quest'ultimo
        Message jm = {MSG_JOIN, "", "", "", "joined the channel."};
        strcpy(jm.sender, msg->sender);
        broadcast(&jm, msg->channel, msg->sender);
    }
}


//messaggi pubblici
static void handle_public(Message *msg) {
    broadcast(msg, msg->channel, msg->sender);
}

//messaggi privati
static void handle_private(Message *msg) {
    int idx = find_user_index(msg->recipient);
    if (idx < 0) {
        //errore se non esiste destinatario o non disponibile
        Message err = {MSG_ERROR, "server", "", "", ""};
        strcpy(err.recipient, msg->sender);
        snprintf(err.text, sizeof(err.text),"User '%s' not available.", msg->recipient);
        char fq[MAX_NAME+8];
        snprintf(fq, sizeof(fq), "%s_fifo", msg->sender);
        //apro la fifo privata del mittente
        int fd = open(fq, O_WRONLY | O_NONBLOCK);
        if (fd != -1) { 
            //messaggio di errore al mittente
            write(fd, &err, sizeof(err));
            close(fd);
        }
    } else {
        //apro la fifo privata del destinatario
        int fd = open(users[idx].fifo, O_WRONLY | O_NONBLOCK);
        if (fd != -1) {
            //messaggio privato al destinatario
            write(fd, msg, sizeof(*msg));
            close(fd); 
            
        }
    }
}

//gestisce la chiusura del server
static void shutdown_server() {
    Message sd = {MSG_SHUTDOWN, "server", "", "", "Server shutting down..."};
    for (int i = 0; i < MAX_USERS; i++) {
        if (users[i].active) {
            //apre la fifo privata per tutti gli utenti attivi
            int fd = open(users[i].fifo, O_WRONLY | O_NONBLOCK);
            if (fd != -1) {
                //manda lo shutdown 
                write(fd, &sd, sizeof(sd));
                close(fd); 
                
            }
        }
    }
}

//inizializza gli utenti come inattivi 
static void initialize_users() {
    for (int i = 0; i < MAX_USERS; i++)
        users[i].active = 0;
}

//gestisce i messaggi in base al tipo 
static void handle_message(Message *msg) {
    switch (msg->type) {
        case MSG_CONNECT:    
            handle_connect(msg);   
            break;
        case MSG_DISCONNECT: 
            handle_disconnect(msg); 
            break;
        case MSG_PUBLIC:    
            handle_public(msg);
            break;
        case MSG_PRIVATE:    
            handle_private(msg);   
            break;
        case MSG_CHANGECH: 
            handle_change_channel(msg); 
            break;
        case MSG_SHUTDOWN: 
            shutdown_server(); 
            exit(0); //esce 
        default: 
            //ignora altri tipi di messaggi
            break;
    }
}

int main(int argc, char *argv[]) {
    //controllo se ho passato il nome della fifo server
    if (argc != 2) {
        printf("errore");
        //esco
        exit(EXIT_FAILURE);
    }
    //inizializzo gli utenti
    initialize_users();
    //creo la fifo con il nome passato (oppure l'ho gia creata fuori allora non serve oppure faccio prima unlink per eliminare la vecchia)
    mkfifo(argv[1], 0666);

    // APRI server_fifo in RDWR non-blocking per evitare blocchi dei client
    int fd_server = open(argv[1], O_RDWR | O_NONBLOCK);
    if (fd_server == -1) {
        printf("errore"); 
        exit(EXIT_FAILURE);
    }

    // handler child
    if (fork() == 0) {
        fd_set rd;
        Message msg;
        while (1) {
            //select per capire quando e su che canale leggere
            FD_ZERO(&rd);
            FD_SET(fd_server, &rd);
            select(fd_server + 1, &rd, NULL, NULL, NULL);
            if (FD_ISSET(fd_server, &rd)) {
                //nel caso possa leggere i messaggi arrivati
                if (read(fd_server, &msg, sizeof(msg)) == sizeof(msg))
                    handle_message(&msg);
            }
        }
    }

    // shutdown-reader child per leggere shutdown dalla stdin
    if (fork() == 0) {
        char buf[128];
        printf("Type 'shutdown' to terminate\n");
        //uso fgets per evitare errori dalla lettura su stdin (in alternativa posso usare scanf  ma devo gestirlo in maniera corretta)
        while (fgets(buf, sizeof(buf), stdin)) {
            if (strncmp(buf, "shutdown", 8) == 0)
                break;
        }
        //uscita
        exit(0);
    }

    // parent: attendi shutdown-reader, poi invia SHUTDOWN al handler, poi attendi handler
    wait(NULL); //attende il processo figlio (non lo specifico so già che il primo che terminera sarà quello che legge shutdown da stdin )
    //invio lo shutdown sulla fifo del server per poter essere letto anche dall'handler in modo che quest'ultimo possa terminare
    Message shut = {MSG_SHUTDOWN, "server", "", "", "Server shutting down..."};
    write(fd_server, &shut, sizeof(shut));
    //attendo il processo handler che termini
    wait(NULL);
    
    //libera le risorse prima di terminare
    //chiudo il descrittore di file
    close(fd_server);
    
    //elimino la fifo del server
    unlink(argv[1]);
    printf("[Server] Shutdown complete.\n");
    return 0;
}

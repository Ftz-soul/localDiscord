#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/select.h>
#include <sys/wait.h>


#define MAX_NAME 32     //massima lunghezza nome utente,canale
#define MAX_TEXT 256    //massima lunghezza messaggio
#define PROMPT "> "   //prompt output

typedef enum {
    MSG_PUBLIC=0,   
    MSG_PRIVATE,   //1
    MSG_CHANGECH,  //2
    MSG_DISCONNECT, //3
    MSG_CONNECT, //4
    MSG_SHUTDOWN, //5
    MSG_ERROR,  //6
    MSG_JOIN, //7
    MSG_LEAVE //8
} MsgType;

typedef struct {
    MsgType type;   //tipo messaggio 
    char sender[MAX_NAME]; //nome del mittente 
    char recipient[MAX_NAME]; // nome del destinatario 
    char channel[MAX_NAME]; //nome canale
    char text[MAX_TEXT]; //testo messaggio 
} Message;


//menu comandi per mandare messaggi
void print_menu() {
    printf("== Comandi Disponibili ==\n");
    printf("/exit           -> disconnetti\n");
    printf("/channel <nome> -> cambia canale\n");
    printf("@utente <msg>   -> privato\n");
    printf("testo normale   -> pubblico\n");
    printf("========================\n");
}

//toglio la new line
void aggiusta(char *s) {
    int l = strlen(s);
    if (l && s[l-1] == '\n') {
        s[l-1] = '\0';
    }
}

//prepara stdout per la pulizia 
void print_incoming(const char *line) {
    // Pulisce riga e ristampa prompt
    printf("\r\033[K%s\n", line);
    printf(PROMPT);
    fflush(stdout);
}




int main(int argc, char *argv[]) {
    //controllo se sono stati passati argomenti nome utente e canale iniziale
    if (argc != 3) {
        printf("errore");
        exit(EXIT_FAILURE);
    }
    
    //isolo il nome utente
    const char *username = argv[1];
    //isolo il nome canale
    char channel[MAX_NAME];
    
    strncpy(channel, argv[2], MAX_NAME);
    
    //fifo privata del client
    char fifo[MAX_NAME + 8];
    //nome fifo client
    snprintf(fifo, sizeof(fifo), "%s_fifo", username);
    //elimino se già esiste 
    unlink(fifo);
    //creo la fifo privata del client con i seguenti permessi (default)
    mkfifo(fifo, 0666);
    
    
    //apro la fifo in sola scrittura per scrivere i messaggi sul server
    int fd_server = open("server_fifo", O_WRONLY);
    if (fd_server == -1) {
        printf("errore server_fifo");
        //elimino la fifo 
        unlink(fifo);
        exit(EXIT_FAILURE);
    }
    //creo la pipe 
    // pipe reader -> writer: connect (1), shutdown/disconnect (2)
    int pipefd[2];
    pipe(pipefd);

    //creo il processo figlio reader
    int  pid_reader = fork();
    if(pid_reader==-1){
        printf("errore");
        exit(EXIT_FAILURE);
    }
    
    
    
    if (pid_reader == 0) {
        // reader client 
        
        //chiudo il lato di lettura dalla pipe usata per comunicare informazioni al writer
        close(pipefd[0]);
        //apro la fifo privata del client in modalità read e write (per eliminare eof)
        int fd_client = open(fifo, O_RDWR);
        if (fd_client == -1) {
            printf("errore"); 
            exit(EXIT_FAILURE); 
            
        }

        Message msg;
        // aspetta MSG_CONNECT
        while (read(fd_client, &msg, sizeof(msg)) > 0) {
            if (msg.type == MSG_CONNECT)
                break;
        }
        char ok=1;
        // segnala al writer che la connect è avvenuta
        write(pipefd[1], &ok, 1);

        // loop ricezione, esce su SHUTDOWN o DISCONNECT
        while (read(fd_client, &msg, sizeof(msg)) > 0) {
            char buf[512];
            //gestisce i tipi dei messaggi 
            switch (msg.type) {
                case MSG_PUBLIC:
                //formato messaggio pubblico [canale][mittente][messaggio]
                    snprintf(buf, sizeof(buf), "[%s][%s]: %s",msg.channel, msg.sender, msg.text);
                    break;
                case MSG_PRIVATE:
                //formato messaggio [priv] [mittente->you]
                    snprintf(buf, sizeof(buf), "[priv][%s->you]: %s",msg.sender, msg.text);
                    break;
                case MSG_JOIN:
                case MSG_LEAVE:
                //join e leave nel canale associato
                    snprintf(buf, sizeof(buf), "*** %s %s", msg.sender, msg.text);
                    break;
                case MSG_ERROR:
                //errori
                    snprintf(buf, sizeof(buf), "ERROR: %s",msg.text);
                    break;
                case MSG_SHUTDOWN:
                case MSG_DISCONNECT:
                    // stampa e segnala writer di uscire
                    snprintf(buf, sizeof(buf), "[server]: %s", msg.text);
                    //sistema output a schermo 
                    print_incoming(buf);
                    //segnala a writer di uscire
                    char ex=2;
                    write(pipefd[1], &ex, 1);
                    //chiudo le risorse usate prima di uscire
                    close(fd_client);
                    close(pipefd[1]);
                    exit(0);
                default:
                    //nel caso type non esistente non gestisce il messaggio 
                    continue;
            }
            //sistemo uscita output
            print_incoming(buf);
        }
        exit(0);
    }

    int pid_writer = fork();
    if(pid_writer==-1){
        printf("errore");
        exit(EXIT_FAILURE);
    }
    if (pid_writer == 0) {
        
        //chiudo lato di scrittura che non utilizza
        close(pipefd[1]);
        // invia CONNECT
        //crea il messaggio 
        Message conn = {MSG_CONNECT, "", "", "", ""};
        strncpy(conn.sender, username, MAX_NAME);
        strncpy(conn.channel, channel, MAX_NAME);
        //scrive al server il messaggio di connessione
        write(fd_server, &conn, sizeof(conn));
        // aspetta la conferma (1) dal processo figlio lettore
        char sig;
        //leggo dalla pipe
        read(pipefd[0], &sig, 1);
        if (sig != 1){
            //siamo nel caso di errore quindi esco 
            exit(EXIT_FAILURE);
        } 
        
        //stampo il menù comandi e il prompt >
        print_menu();
        printf(PROMPT);
        fflush(stdout);

        char line[MAX_TEXT];
        while (1) {
            //imposto la select
            
 //FD_ZERO(&rd): azzera il set dei file descriptor.

//FD_SET(fd, &rd): aggiunge un descriptor (STDIN_FILENO o pipefd[0]) al set da controllare.
//select(mx+1, &rd, NULL, NULL, NULL): sospende l’esecuzione finché almeno uno dei fd nel set non diventa leggibile.
//FD_ISSET(fd, &rd): dopo select, verifica per ciascun fd se è stato segnato come “pronto”.
//In questo modo il writer può ascoltare in parallelo sia l’input utente che i segnali di shutdown/disconnect provenienti dal suo reader, senza mai bloccare né usare sleep né busy‐loop.
            fd_set rd;
            FD_ZERO(&rd);
            FD_SET(STDIN_FILENO, &rd);
            FD_SET(pipefd[0],  &rd);
            int mx = STDIN_FILENO > pipefd[0] ? STDIN_FILENO : pipefd[0];
           
            //mx + 1: è il numero massimo di file descriptor da controllare più 1. È importante perché select controlla tutti i file descriptor da 0 fino a mx.
            //&rd: è l'insieme dei file descriptor che vogliamo controllare per eventi in lettura.
            //NULL: non controlliamo fd in scrittura.
            //NULL: non controlliamo fd per eccezioni.
            //NULL: significa nessun timeout, quindi select si blocca indefinitamente finché almeno un fd diventa pronto.
            select(mx+1, &rd, NULL, NULL, NULL);

            // se arriva shutdown/disconnect passa a leggere sulla pipe 
            if (FD_ISSET(pipefd[0], &rd)) {
                char x; 
                read(pipefd[0], &x, 1);
                //se è 2 allora shutdown
                if (x == 2) 
                    break;
            }
            
            // input utente su stdin
            if (FD_ISSET(STDIN_FILENO, &rd)) {
                if (!fgets(line, sizeof(line), stdin)) continue;
                //aggiusto il messaggio letto 
                aggiusta(line);
                //costruisco il messaggio con mittente (nome user ), channel (nome canale )
                Message out = {0};
                strncpy(out.sender,  username, MAX_NAME);
                strncpy(out.channel, channel,  MAX_NAME);
                
                
                //se viene digitato /exit deve essere inviata la disconnessione al server
                if (strcmp(line, "/exit") == 0) {
                    out.type = MSG_DISCONNECT;
                    strncpy(out.text, "You have disconnected.", MAX_TEXT);
                    write(fd_server, &out, sizeof(out));
                    break;
                }
                
                //se viene digitato /channel nomecanale deve essere inviato un messaggio al server per cambiare il canale con il nuovo canale specificato
                else if (strncmp(line, "/channel ", 9) == 0) {
                    out.type = MSG_CHANGECH;
                    strncpy(out.channel, line+9, MAX_NAME);
                    strncpy(channel,    line+9, MAX_NAME);
                    write(fd_server, &out, sizeof(out));
                }
                
                //verifico se il primo carattere del messaggio è @ seguita da nome destinatario e staccato il messaggio allora è un messaggio privato 
                else if (line[0] == '@') {
                    out.type = MSG_PRIVATE;
                    
                    char *sp = strchr(line, ' ');
                    if (sp) {
                        *sp = '\0';
                        strncpy(out.recipient, line+1, MAX_NAME);
                        strncpy(out.text,      sp+1,   MAX_TEXT);
                        //mando il messaggio al server (indirizzato a utente specificato)
                        write(fd_server, &out, sizeof(out));
                    }
                }
                else {
                    //se non c'è @ è messaggio pubblico del canale
                    out.type = MSG_PUBLIC;
                    strncpy(out.text, line, MAX_TEXT);
                    //lo invio al server
                    write(fd_server, &out, sizeof(out));
                }
                //ristampo il prompt per il prossimo messaggio 
                printf(PROMPT);
                fflush(stdout);
            }
        }
        //esce 
        exit(0);
    }
    
    // padre
    //attende terminazione figli 
    // aspetta reader (shutdown/disconnect), poi writer
    waitpid(pid_reader, NULL, 0);
    waitpid(pid_writer, NULL, 0);
    
    
    //pulisco le risorse
    close(fd_server);
    unlink(fifo);
    return 0;
}
